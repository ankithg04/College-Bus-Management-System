<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Page Title</title>
<script type="text/javascript">
  function direct(clicked_id)
  {
    if(clicked_id=="admin")
      window.location="admin/adminlogin.php";
    if(clicked_id=="student")
      window.location="student/studentlogin.php";

  }
</script>
<style type="text/css">
  .select{
    padding-top: 400px;
    padding-left: 600px;
    font-family: cursive;
    font-size: 30px;
  }

</style>>
<link rel='stylesheet' type='text/css' href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700'>

  <!-- Theme CSS -->
  <link rel="stylesheet" type="text/css" href="admin/assets/skin/default_skin/css/theme.css">

  <!-- Admin Forms CSS -->
  <link rel="stylesheet" type="text/css" href="admin/assets/admin-tools/admin-forms/css/admin-forms.css">

  <!-- Favicon -->
  <link rel="shortcut icon" href="admin/assets/img/favicon.ico">
</head>
<body class="external-page sb-l-c sb-r-c">
  <div id="main" class="animated fadeIn">

    <!-- Start: Content-Wrapper -->
    <section id="content_wrapper">

      <!-- begin canvas animation bg -->
      <div id="canvas-wrapper">
        <canvas id="demo-canvas"></canvas>
      </div >
      <div id="canvas-wrapper">
          <img src="college.jpeg" alt="college img" style="width:100%;height: 400px;" />

      </div>
      <div id="canvas-wrapper" class="select">
              <div>
                <button type="" class="button btn-primary mr10 pull-left" id="admin" onclick="direct(id);">ADMIN LOGIN</button><br><br>
              </div>
              <div>
                <button type="" class="button btn-primary mr10 pull-left" id="student" onclick="direct(id);">STUDENT LOGIN</button>
              </div>

      </div>
  </section>

      <script src="admin/vendor/jquery/jquery-1.11.1.min.js"></script>
  <script src="admin/vendor/jquery/jquery_ui/jquery-ui.min.js"></script>

  <!-- CanvasBG Plugin(creates mousehover effect) -->
  <script src="admin/vendor/plugins/canvasbg/canvasbg.js"></script>

  <!-- Theme Javascript -->
  <script src="admin/assets/js/utility/utility.js"></script>
  <script src="admin/assets/js/demo/demo.js"></script>
  <script src="admin/assets/js/main.js"></script>

  <!-- Page Javascript -->
  <script type="text/javascript">
  jQuery(document).ready(function() {

    "use strict";


    // Init CanvasBG and pass target starting location
    CanvasBG.init({
      Loc: {
        x: window.innerWidth / 2,
        y: window.innerHeight / 3.3
      },
    });

  });
  </script>


</body>
</html>
