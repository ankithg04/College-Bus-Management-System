<?php
   include("adminheader.php");
   include("sparkle.css");

   ?>
    <!-- End: Sidebar Left -->

    <!-- Start: Content-Wrapper -->
    <section id="content_wrapper">

        <!-- Start: Topbar-Dropdown -->

        <!-- Start: Topbar -->
        <header id="topbar" class="alt">
            <div class="topbar-left">
                <ol class="breadcrumb">
                    <li class="crumb-active">
                        <a href="dashboard.html">Dashboard</a>
                    </li>
                    <li class="crumb-icon">
                        <a href="dashboard.html">
                            <span class="glyphicon glyphicon-home"></span>
                        </a>
                    </li>
                    <li class="crumb-link">
                        <a href="index.html">Home</a>
                    </li>
                    <li class="crumb-trail">ABOUT US</li>
                </ol>
            </div>
               </header>
        <!-- End: Topbar -->

        <!-- Begin: Content -->
        <section id="content" class="table-layout animated fadeIn">

            <!-- begin: .tray-center -->
            <div class="tray tray-center">
                <p><div class="Sparkle"><marquee><b><h1>Designed and Developed by</h1></b></marquee></div><br/></p>
              <p>  <h3>Chandan M     (4mu15cs010) Computer science and engineering</h3><br/>
                <h3>Maheshwara SJ (4mu15cs033) Computer science and engineering</h3><br/>
                <h3>Sandesh S     (4mu15cs059) Computer science and engineering</h3><br/>
            </p>

            </div>
        </section>                    
        <!-- End: Content -->
<?php
   include("adminfooter.php");

   ?>