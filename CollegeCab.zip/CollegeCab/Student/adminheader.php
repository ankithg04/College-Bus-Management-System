<?php
 include('studentsession.php');
?>

<!DOCTYPE html>
<html>
<head>
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <title>Student Dashboard</title>
    
    <link rel='stylesheet' type='text/css' href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700'>

    <!-- FullCalendar Plugin CSS -->
    <link rel="stylesheet" type="text/css" href="vendor/plugins/fullcalendar/fullcalendar.min.css">

    <!-- Theme CSS -->
    <link rel="stylesheet" type="text/css" href="assets/skin/default_skin/css/theme.css">

    <!-- Admin Forms CSS -->
    <link rel="stylesheet" type="text/css" href="assets/admin-tools/admin-forms/css/admin-forms.min.css">

    <!-- Favicon -->
    <link rel="shortcut icon" href="assets/img/favicon.ico">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

</head>

<body class="dashboard-page">

<div id="main">

    <header class="navbar navbar-fixed-top navbar-shadow bg-info" style="background:#02adff;"">
        <div class="navbar-branding" >
            <a class="navbar-brand" href="index.php">
                <b style="color:#283850; font-size: 40px;">Student</b> Dashboard
            </a>
            <span id="toggle_sidemenu_l" class="ad ad-lines"></span>
        </div>
        <ul class="nav navbar-nav navbar-left" >
           
            <li class="hidden-xs">
                <a class="request-fullscreen toggle-active" href="#">
                    <span class="ad ad-screen-full fs18"></span>
                </a>
            </li>
        </ul>
        <form class="navbar-form navbar-left navbar-search alt" role="search">
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Search..." value="Search...">
            </div>
        </form>
        <ul class="nav navbar-nav navbar-right">

            <li class="dropdown menu-merge">
                <div class="navbar-btn btn-group">
                    <button class="btn btn-sm dropdown-toggle">
                        <span class="flag-xs flag-in"></span>
                        <!-- <span class="caret"></span> -->
                    </button>
                    
                </div>
            </li>
            <li class="menu-divider hidden-xs">
                <i class="fa fa-circle"></i>
            </li>
            <li class="dropdown menu-merge">
                <a href="#" class="dropdown-toggle fw600 p15" data-toggle="dropdown">
                    <img src="assets/img/avatars/1.jpg" alt="avatar" class="mw30 br64">
                    <span class="hidden-xs pl15"> 

<?php 
                echo "".$_SESSION['name']."";

                ?>

                    </span>
                    <span class="caret caret-tp hidden-xs"></span>
                </a>
                <ul class="dropdown-menu list-group dropdown-persist w250" role="menu">
    
                    
                    </li>
                    <li class="dropdown-footer">
                        <a href="logout.php" class="">
                            <span class="fa fa-power-off pr5"></span> Logout </a>
                    </li>
                </ul>
            </li>
        </ul>
    </header>
    
    <aside id="sidebar_left" class="nano nano-light affix">

        <!-- Start: Sidebar Left Content -->
        <div class="sidebar-left-content nano-content" style="right: -17px;background-color: #222531;" >

            <!-- Start: Sidebar Header -->
            <header class="sidebar-header">

                <!-- Sidebar Widget - Author -->
                <div class="sidebar-widget author-widget">
                    <div class="media">
                        <a class="media-left" href="#">
                            <img src="assets/img/avatars/3.jpg" class="img-responsive">
                        </a>

                        <div class="media-body">
                            <div class="media-links">
                             <a href="logout.php">Logout</a>
                            </div>
                            <div class="media-author">
<?php 
                echo "".$_SESSION['name']."";

                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- End: Sidebar Header -->

            <!-- Start: Sidebar Menu -->
            <ul class="nav sidebar-menu">
                <li class="sidebar-label pt20">Menu</li>
                <li class="active">
                    <a href="studentdash.php">
                        <span class="glyphicon glyphicon-home"></span>
                        <span class="sidebar-title">Dashboard</span>
                    </a>
                </li>
                <li class="sidebar-label pt15">Manage</li>
                <li>
                    <a class=" " href="stdbusview.php">
                     <span class="glyphicon glyphicon-user"></span>
                        <span class="sidebar-title">YOUR ROUTE DETAILS</span>
                     
                    </a>
                </li>
                <li>
                    <a class=" " href="about.php">
                     <span class="glyphicon glyphicon-user"></span>
                        <span class="sidebar-title">ABOUT US</span>
                     
                    </a>
                </li>
            </ul>
            <!-- End: Sidebar Menu -->

            <!-- Start: Sidebar Collapse Button -->
            <!-- End: Sidebar Collapse Button -->

        </div>
        <!-- End: Sidebar Left Content -->

    </aside>