<?php
# include('studentsession.php');
 include('db.php');
 if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
  
      $name = mysqli_real_escape_string($conn,$_POST['username']);
      $usn = mysqli_real_escape_string($conn,$_POST['usn']); 
      $phone = mysqli_real_escape_string($conn,$_POST['phone']);
      $pwd = mysqli_real_escape_string($conn,$_POST['pwd']);
      $stop = mysqli_real_escape_string($conn,$_POST['stop']);
      $sql="INSERT INTO Studenttb (usn,name,password,stop,phonenum,approve) VALUES('$usn','$name','$pwd','$stop','$phone','no')";
        if ($conn->query($sql) === TRUE){
            $message="YOU REGISTRATION WAS SUCCESSFULL";
        }else{
            $message ="NOT INSERTED";
        }
        echo"<script>alert($message);</script>";

header("location:studentlogin.php");
   }
?>


<!DOCTYPE html>
<html>
<head>
  <!-- Meta, title, CSS, favicons, etc. -->
  <meta charset="utf-8">
  <title>User Login</title>

<link rel='stylesheet' type='text/css' href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700'>

  <!-- Theme CSS -->
  <link rel="stylesheet" type="text/css" href="assets/skin/default_skin/css/theme.css">

  <!-- Admin Forms CSS -->
  <link rel="stylesheet" type="text/css" href="assets/admin-tools/admin-forms/css/admin-forms.css">

  <!-- Favicon -->
  <link rel="shortcut icon" href="assets/img/favicon.ico">


</head>

<body class="external-page sb-l-c sb-r-c">

  <!-- Start: Main -->
  <div id="main" class="animated fadeIn">

    <!-- Start: Content-Wrapper -->
    <section id="content_wrapper">

      <!-- begin canvas animation bg -->
      <div id="canvas-wrapper">
        <canvas id="demo-canvas"></canvas>
      </div>

      <!-- Begin: Content -->
      <section id="content">

        <div class="admin-form theme-info" id="login1">

          <div class="row mb15 table-layout">

            <div class="col-xs-6 va-m pln">
                <h1>STUDENT LOGIN</h1>
            </div>

            <div class="col-xs-6 text-right va-b pr5">
              <div class="login-links">
                <a href="#" class="active" title="Sign In">Sign In</a>
                <span class="text-white"> | </span>
                <a href="studentreg.php" class="" title="Register">Register</a>
              </div>

            </div>

          </div>

          <div class="panel panel-info mt10 br-n">

            <div class="panel-heading heading-border bg-white">
              <span class="panel-title hidden">
                <i class="fa fa-sign-in"></i>Register</span>
              
            </div>

         <form method="POST" action="" id="contact">
              <div class="panel-body bg-light p30">
                <div class="row">
                  <div class="col-sm-7 pr30">

                    <p><b>REGISTRATION FORM</b></p>                    

                    <div class="section">
                      <label for="username" class="field-label text-muted fs18 mb10">NAME</label>
                     <br>
                        <input type="text" name="username" id="username" class="gui-input" placeholder="Enter username">
                        
                        
                    </div>
                    <div class="section">
                      <label for="username" class="field-label text-muted fs18 mb10">USN</label>
                     <br> 
                        <input type="text" name="usn" id="username" class="gui-input" placeholder="Enter address">
                    </div>


                    <div class="section">
                      <label for="username" class="field-label text-muted fs18 mb10">Phone Number</label>
                      <br>
                        <input type="text" name="phone" id="username" class="gui-input" placeholder="Enter phone number">
                    </div>


                    <div class="section">
                      <label for="username" class="field-label text-muted fs18 mb10">PASSWORD</label>
                      <br>
                        <input type="password" name="pwd" id="username" class="gui-input" placeholder="Enter PASSWORD">
                    </div>

                    <div class="section">
                      <label for="username" class="field-label text-muted fs18 mb10">STOP NAME</label>
                      <br>
                        <input type="text" name="stop" id="username" class="gui-input" placeholder="Enter stop name">
                        <br>
                    </div>

                     <div class="panel-footer clearfix p10 ph15">
                      <br>
                <button type="" class="button btn-primary mr10 pull-left">SUBMIT</button>
              </div>           

                  </div>
                  
                </div> 
              </div>
       
</form>
          </div>
        </div>

      </section>
      <!-- End: Content -->

    </section>
    <!-- End: Content-Wrapper -->

  </div>
  <!-- End: Main -->

  <!-- BEGIN: PAGE SCRIPTS -->

  <!-- jQuery -->
  <script src="vendor/jquery/jquery-1.11.1.min.js"></script>
  <script src="vendor/jquery/jquery_ui/jquery-ui.min.js"></script>

  <!-- CanvasBG Plugin(creates mousehover effect) -->
  <script src="vendor/plugins/canvasbg/canvasbg.js"></script>

  <!-- Theme Javascript -->
  <script src="assets/js/utility/utility.js"></script>
  <script src="assets/js/demo/demo.js"></script>
  <script src="assets/js/main.js"></script>

  <!-- Page Javascript -->
  <script type="text/javascript">
  jQuery(document).ready(function() {

    "use strict";


    // Init CanvasBG and pass target starting location
    CanvasBG.init({
      Loc: {
        x: window.innerWidth / 2,
        y: window.innerHeight / 3.3
      },
    });

  });
  </script>

  <!-- END: PAGE SCRIPTS -->

</body>

</html>
