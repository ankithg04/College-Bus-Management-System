 <?php
  if(!isset($_SESSION['usn'])){
  	// echo $_SESSION['Email'];
      header("location:studentlogin.php");
   }
   else
   {

   	header("location:studentdash.php");
   }
   ?>