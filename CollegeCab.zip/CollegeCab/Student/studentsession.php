<?php
  include('db.php');
   session_start();
  


  if(!isset($_SESSION['usn'])){
  	// echo $_SESSION['Email'];
      header("location:studentlogin.php");
   }
?>