<?php
   include("adminheader.php");
   include("../include/db.php");


   ?>
    <!-- End: Sidebar Left -->

    <!-- Start: Content-Wrapper -->
    <section id="content_wrapper">

        <!-- Start: Topbar-Dropdown -->

        <!-- Start: Topbar -->
        <header id="topbar" class="alt">
            <div class="topbar-left">
                <ol class="breadcrumb">
                    <li class="crumb-active">
                        <a href="dashboard.html">Dashboard</a>
                    </li>
                    <li class="crumb-icon">
                        <a href="dashboard.html">
                            <span class="glyphicon glyphicon-home"></span>
                        </a>
                    </li>
                    <li class="crumb-link">
                        <a href="index.html">Home</a>
                    </li>
                    <li class="crumb-trail">YOUR ROUTE DETAILS</li>
                </ol>
            </div>
               </header>
        <!-- End: Topbar -->

        <!-- Begin: Content -->
        <section id="content" class="table-layout animated fadeIn">

            <!-- begin: .tray-center -->
            <div class="tray tray-center">
                <p>Welcome, <b><?php 
                echo "".$_SESSION['name']."</b></p>";

                ?></b></p>
                <form method="GET" action="" id="contact">

                 <div class="section">
                      <label for="username" class="field-label text-muted fs18 mb10">ENTER YOUR USN</label>
                      <br>
                        <input type="text" name="usn" id="username" class="gui-input" placeholder="Enter usn">
                    </div>
                    <div class="panel-footer clearfix p10 ph15">
                <button type="" class="button btn-primary mr10 pull-left">SUBMIT</button>
              </div>  
              </form>         

<div class="panel-body bg-light p30">
                <div class="row">
                  <div class="col-sm-7 pr30">
 <div class="panel-heading">
              <span class="panel-title">
                <span class="fa fa-table"></span>YOUR ROUTE Details</span>
              
            </div>
              <div class="panel-body pn">
              <div class="">
                <table class="table table-striped">
                        <?php 
                      error_reporting(0);
                  if($_SERVER["REQUEST_METHOD"] == "GET") {
                  	$usn=mysqli_real_escape_string($conn,$_GET['usn']);
                    $sql="select * from Routetb where rid IN (select rid from studbustb where sid IN (select sid from studenttb where usn= '$usn')) ";
                    $result = $conn->query($sql);
                    if($result->num_rows >0) 
                    {$i=0;
                       echo' <tr><th>sl.no</th><th>Route id</th><th>Route Source </th><th>Route Destination</th><th>View Route Details</th></tr>';
                    // output data of each row
                    while($row = $result->fetch_assoc()) 
                    {
                    $i++; 
                    echo ('<tr><td>'.$i.'</td><td>'.$row["Rid"].'</td><td>'.$row["Rfrom"].'</td><td>'.$row["Rto"].'</td><td><a href="viewroute.php?Rid='.$row["Rid"].'">View</a></td></tr>');
                    
                    }
                    }
    else
    {
    	$usn=mysqli_real_escape_string($conn,null);
    echo"Enter USN";
        }
    

}
                  ?>
       </table>
              </div>
            </div>

</div>
</div>
</div>


              <!-- end .form-body section -->
              <!-- end .form-footer section -->
 
            </div>

        </section>                    
        <!-- End: Content -->
<?php
   include("adminfooter.php");

   ?>
