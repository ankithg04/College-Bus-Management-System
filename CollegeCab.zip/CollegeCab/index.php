<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Page Title</title>
<style type="text/css">
	h3{
		padding-top: 400px;
		left:50%;
	}

</style>>
<link rel='stylesheet' type='text/css' href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700'>

  <!-- Theme CSS -->
  <link rel="stylesheet" type="text/css" href="admin/assets/skin/default_skin/css/theme.css">

  <!-- Admin Forms CSS -->
  <link rel="stylesheet" type="text/css" href="admin/assets/admin-tools/admin-forms/css/admin-forms.css">

  <!-- Favicon -->
  <link rel="shortcut icon" href="admin/assets/img/favicon.ico">
</head>
<body class="external-page sb-l-c sb-r-c">
	<div id="main" class="animated fadeIn">

    <!-- Start: Content-Wrapper -->
    <section id="content_wrapper">

      <!-- begin canvas animation bg -->
      <div id="canvas-wrapper">
        <canvas id="demo-canvas"></canvas>
      </div >
      <div id="canvas-wrapper">
      		<img src="college.jpeg" alt="college img" style="width:100%;height: 400px;" />

      </div>
      <div id="canvas-wrapper">
      	<h3 style="text-align:center"><a style="text-decoration:none;color: red;" href="selectusr.php"><strong>Click here for "College Bus Management System"</strong>	</a></h3>

      </div>
  </section>

      <script src="admin/vendor/jquery/jquery-1.11.1.min.js"></script>
  <script src="admin/vendor/jquery/jquery_ui/jquery-ui.min.js"></script>

  <!-- CanvasBG Plugin(creates mousehover effect) -->
  <script src="admin/vendor/plugins/canvasbg/canvasbg.js"></script>

  <!-- Theme Javascript -->
  <script src="admin/assets/js/utility/utility.js"></script>
  <script src="admin/assets/js/demo/demo.js"></script>
  <script src="admin/assets/js/main.js"></script>

  <!-- Page Javascript -->
  <script type="text/javascript">
  jQuery(document).ready(function() {

    "use strict";


    // Init CanvasBG and pass target starting location
    CanvasBG.init({
      Loc: {
        x: window.innerWidth / 2,
        y: window.innerHeight / 3.3
      },
    });

  });
  </script>


</body>
</html>
