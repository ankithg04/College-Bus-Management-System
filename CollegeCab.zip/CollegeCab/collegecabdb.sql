-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2018 at 04:55 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `collegecabdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admintb`
--

CREATE TABLE `admintb` (
  `Aid` int(30) NOT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admintb`
--

INSERT INTO `admintb` (`Aid`, `Email`, `Name`, `Password`) VALUES
(1, 'admin@CMS.com', 'Admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `busdrivertb`
--

CREATE TABLE `busdrivertb` (
  `bdid` int(30) NOT NULL,
  `bid` int(30) DEFAULT NULL,
  `did` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `busdrivertb`
--

INSERT INTO `busdrivertb` (`bdid`, `bid`, `did`) VALUES
(1, 2, 1),
(2, 3, 3),
(3, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `busroutetb`
--

CREATE TABLE `busroutetb` (
  `brid` int(30) NOT NULL,
  `bid` int(30) DEFAULT NULL,
  `rid` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `busroutetb`
--

INSERT INTO `busroutetb` (`brid`, `bid`, `rid`) VALUES
(1, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `bustb`
--

CREATE TABLE `bustb` (
  `bid` int(30) NOT NULL,
  `bNum` int(100) DEFAULT NULL,
  `bSeat` int(100) DEFAULT NULL,
  `brNum` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bustb`
--

INSERT INTO `bustb` (`bid`, `bNum`, `bSeat`, `brNum`) VALUES
(2, 1, 55, 'Ka-09 AA-11'),
(3, 3, 55, 'ka-09 bb-99');

-- --------------------------------------------------------

--
-- Table structure for table `drivertb`
--

CREATE TABLE `drivertb` (
  `did` int(30) NOT NULL,
  `dname` varchar(100) DEFAULT NULL,
  `daddress` varchar(100) DEFAULT NULL,
  `dphone` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `drivertb`
--

INSERT INTO `drivertb` (`did`, `dname`, `daddress`, `dphone`) VALUES
(1, 'ramu', '', '099887654321'),
(3, 'soma', 'address', '8786879567');

-- --------------------------------------------------------

--
-- Table structure for table `routetb`
--

CREATE TABLE `routetb` (
  `Rid` int(40) NOT NULL,
  `Rfrom` varchar(100) DEFAULT NULL,
  `Rto` varchar(100) DEFAULT NULL,
  `Rstops` varchar(10000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `routetb`
--

INSERT INTO `routetb` (`Rid`, `Rfrom`, `Rto`, `Rstops`) VALUES
(1, 'Vijaynagar ', 'laximipura', 'a s d f f f g g g\r\n\r\n'),
(3, 'demo', 'demo', 'a f g h j k k l');

-- --------------------------------------------------------

--
-- Table structure for table `studbustb`
--

CREATE TABLE `studbustb` (
  `sbid` int(30) NOT NULL,
  `sid` int(30) DEFAULT NULL,
  `rid` int(30) DEFAULT NULL,
  `approve` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studbustb`
--

INSERT INTO `studbustb` (`sbid`, `sid`, `rid`, `approve`) VALUES
(1, 1, 3, 'yes'),
(2, 3, 1, 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `studenttb`
--

CREATE TABLE `studenttb` (
  `sid` int(10) NOT NULL,
  `usn` varchar(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `stop` varchar(200) DEFAULT NULL,
  `phonenum` varchar(13) DEFAULT NULL,
  `approve` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studenttb`
--

INSERT INTO `studenttb` (`sid`, `usn`, `name`, `password`, `stop`, `phonenum`, `approve`) VALUES
(1, '4mu15cs001', 'abcd', 'abcd', 'a', '8556666666', 'yes'),
(3, '4MU15CS004', 'Ankith', '8746850422', 'FTS', '8746580422', 'yes'),
(4, '4MU15CS002', 'Abhishek', '1234', 'Fountain Circle', '9876543211', 'yes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admintb`
--
ALTER TABLE `admintb`
  ADD PRIMARY KEY (`Aid`);

--
-- Indexes for table `busdrivertb`
--
ALTER TABLE `busdrivertb`
  ADD PRIMARY KEY (`bdid`),
  ADD KEY `bid` (`bid`),
  ADD KEY `did` (`did`);

--
-- Indexes for table `busroutetb`
--
ALTER TABLE `busroutetb`
  ADD PRIMARY KEY (`brid`),
  ADD KEY `bid` (`bid`),
  ADD KEY `rid` (`rid`);

--
-- Indexes for table `bustb`
--
ALTER TABLE `bustb`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `drivertb`
--
ALTER TABLE `drivertb`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `routetb`
--
ALTER TABLE `routetb`
  ADD PRIMARY KEY (`Rid`);

--
-- Indexes for table `studbustb`
--
ALTER TABLE `studbustb`
  ADD PRIMARY KEY (`sbid`),
  ADD KEY `sid` (`sid`),
  ADD KEY `rid` (`rid`);

--
-- Indexes for table `studenttb`
--
ALTER TABLE `studenttb`
  ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admintb`
--
ALTER TABLE `admintb`
  MODIFY `Aid` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `busdrivertb`
--
ALTER TABLE `busdrivertb`
  MODIFY `bdid` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `busroutetb`
--
ALTER TABLE `busroutetb`
  MODIFY `brid` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bustb`
--
ALTER TABLE `bustb`
  MODIFY `bid` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `drivertb`
--
ALTER TABLE `drivertb`
  MODIFY `did` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `routetb`
--
ALTER TABLE `routetb`
  MODIFY `Rid` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `studbustb`
--
ALTER TABLE `studbustb`
  MODIFY `sbid` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `studenttb`
--
ALTER TABLE `studenttb`
  MODIFY `sid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `busdrivertb`
--
ALTER TABLE `busdrivertb`
  ADD CONSTRAINT `busdrivertb_ibfk_1` FOREIGN KEY (`bid`) REFERENCES `bustb` (`bid`),
  ADD CONSTRAINT `busdrivertb_ibfk_2` FOREIGN KEY (`did`) REFERENCES `drivertb` (`did`);

--
-- Constraints for table `busroutetb`
--
ALTER TABLE `busroutetb`
  ADD CONSTRAINT `busroutetb_ibfk_1` FOREIGN KEY (`bid`) REFERENCES `bustb` (`bid`),
  ADD CONSTRAINT `busroutetb_ibfk_2` FOREIGN KEY (`rid`) REFERENCES `routetb` (`Rid`);

--
-- Constraints for table `studbustb`
--
ALTER TABLE `studbustb`
  ADD CONSTRAINT `studbustb_ibfk_1` FOREIGN KEY (`sid`) REFERENCES `studenttb` (`sid`),
  ADD CONSTRAINT `studbustb_ibfk_2` FOREIGN KEY (`rid`) REFERENCES `routetb` (`Rid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
