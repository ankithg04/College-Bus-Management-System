<?php
   include("adminheader.php");

if($_SERVER["REQUEST_METHOD"] == "GET") {
      // username and password sent from form
$val1 = mysqli_real_escape_string($conn,$_GET['studDDL']);
$val2 = mysqli_real_escape_string($conn,$_GET['routeDDL']);
$sql2="INSERT INTO studbustb (sid,rid,approve) values($val1,$val2,'yes')";
//echo'<script>alert('')</scriptt>'
if ($conn->query($sql2) === TRUE){
            $message="INSERTED SUCESSFULLY";
            header("location: studbus.php");
        }else{
            $message ="NOT INSERTED";
            header("location: studbus.php");
        }

header("location: studbus.php");
   }


   ?>
  <section id="content_wrapper">

        <!-- Start: Topbar-Dropdown -->

        <!-- Start: Topbar -->
        <header id="topbar" class="alt">
            <div class="topbar-left">
                <ol class="breadcrumb">
                    <li class="crumb-active">
                        <a href="dashboard.html">Dashboard</a>
                    </li>
                    <li class="crumb-icon">
                        <a href="dashboard.html">
                            <span class="glyphicon glyphicon-home"></span>
                        </a>
                    </li>
                    <li class="crumb-link">
                        <a href="index.html">Home</a>
                    </li>
                    <li class="crumb-trail">Student-Bus Details</li>
                </ol>
            </div>
               </header>
        <!-- End: Topbar -->

        <!-- Begin: Content -->
        <section id="content" class="table-layout animated fadeIn">

            <!-- begin: .tray-center -->
            <div class="tray tray-center">
                <p>Welcome, <b>Admin</b></p>

            </div>
        </section> 


<div class="col-md-12">
             <form method="GET" action="" id="contact">
              <div class="panel-body bg-light p30">
                <div class="row">
                  <div class="col-sm-7 pr30">

                    <p><b>Student-Route Allocation</b></p>                    

                    <div class="section">
                      <label for="username" class="field-label text-muted fs18 mb10">Select Student</label> 
                     <br>
                     <form metod="post" action ="" ">
                        <select name="studDDL"><option value="0">-----SELECT-----</option>
                        <?php
                        $sql1="SELECT B.sid,B.name,B.usn from studenttb B where B.sid NOT IN (SELECT BR.sid from studbustb BR)";
#<select name="busDDL" onchange="window.location='busdriver.php?bid='+(this.value);"><option value="0">-----SELECT-----</option>

                          echo'';

                           $result = $conn->query($sql1);
                            if($result->num_rows >0) 
                            {
                                while($row = $result->fetch_assoc()) 
                                  {
                                echo '<option value="'.$row["sid"].'">'.$row["name"].'('.$row["usn"].')</option>';
                                  
                                  }
                            }
                            else{


                            }

                          echo"</select>";
                        ?>   
                    </div>

                    
                    <div class="section">
                      <label for="username" class="field-label text-muted fs18 mb10">Select Route</label>
                     <br> 
                      <select name="routeDDL"><option value="0">-----SELECT-----</option>
                        <?php
                        $sql3="select rid,rfrom,rto from routetb " ;

                          echo'';

                           $result3 = $conn->query($sql3);
                            if($result3->num_rows >0) 
                            {
                                while($row3 = $result3->fetch_assoc()) 
                                  {
                                echo '<option value="'.$row3["rid"].'">'.$row3["rfrom"].' to '.$row3["rto"].'</option>';
                                  
                                  }
                            }
                            else{


                            }

                          echo"</select>";
                        ?>


                    </div>


                  </div>
                  
                </div> 
              </div>
        <div class="panel-footer clearfix p10 ph15">
                <button type="" class="button btn-primary mr10 pull-left">Allocate bus to student</button>
              </div>           
</form>
            </div>
              

              <div class="col-md-12">
              <div class="panel panel-visible" id="spy2">
                <div class="panel-heading">
                  <div class="panel-title hidden-xs">
                    <span class="glyphicon glyphicon-tasks"></span>Student Route Details</div>
                </div>
                <div class="panel-body pn">
                  <table class="table table-striped table-hover" id="datatable2" cellspacing="0" width="100%">
        <?php
         
           $sql1="select S.usn,S.name,S.stop,R.Rfrom,R.Rto,S.sid from studbustb SB INNER JOIN studenttb S on S.sid=SB.sid INNER JOIN routetb R on R.Rid=SB.Rid where SB.approve='yes'";
        $result1 = $conn->query($sql1);
                    if($result1->num_rows >0) 
                    {$i=0;
                       echo' <tr><th>sl.no</th><th>Name</th><th>USN</th><th>Stop</th><th>Source to Destination</th><th>Delete</th></tr>';
                    // output data of each row
                    while($row1 = $result1->fetch_assoc()) 
                    {
                    $i++; 
                    echo ('<tr><td>'.$i.'</td><td>'.$row1["name"].'</td><td>'.$row1["usn"].'</td><td>'.$row1["stop"].'</td><td>'.$row1["Rfrom"].' to '.$row1["Rto"].'</td><td><a href="delstudbus.php?sid='.$row1["sid"].'">delete</a></td></tr>');
                    
                    }
                    }
    else
    {
    echo"0 results";
        }



        ?> 
             </table>
                </div>
              </div>
            </div>

<?php
   include("adminfooter.php");
   ?>