<?php
   include("adminheader.php");
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
  
      $Busid = mysqli_real_escape_string($conn,$_POST['bid']);
      $BusSeat = mysqli_real_escape_string($conn,$_POST['bseat']); 
      $BusReg = mysqli_real_escape_string($conn,$_POST['brnum']);
      $sql="INSERT INTO Bustb (bNum,bSeat,brNum)
    VALUES('$Busid','$BusSeat','$BusReg')";
        if ($conn->query($sql) === TRUE){
            $message="INSERTED SUCESSFULLY";
        }else{
            $message ="NOT INSERTED";
        }

header("location: BusDet.php");
   }
if($_SERVER["REQUEST_METHOD"] == "GET") {
      // username and password sent from form 
  
      $bid = mysqli_real_escape_string($conn,$_GET['bid']);
     
      $sql="Delete from bustb where bid=$bid";
        if ($conn->query($sql) === TRUE){
            $message="DELETED SUCESSFULLY";
        }else{
            $message ="NOT DELETED";
        }

header("location: BusDet.php");
   }

   ?>
    <!-- End: Sidebar Left -->

    <!-- Start: Content-Wrapper -->
    <section id="content_wrapper">

        <!-- Start: Topbar-Dropdown -->

        <!-- Start: Topbar -->
        <header id="topbar" class="alt">
            <div class="topbar-left">
                <ol class="breadcrumb">
                    <li class="crumb-active">
                        <a href="dashboard.html">Dashboard</a>
                    </li>
                    <li class="crumb-icon">
                        <a href="dashboard.html">
                            <span class="glyphicon glyphicon-home"></span>
                        </a>
                    </li>
                    <li class="crumb-link">
                        <a href="index.php">Home</a>
                    </li>
                    <li class="crumb-trail">Bus Details</li>
                </ol>
            </div>
               </header>
        <!-- End: Topbar -->

        <!-- Begin: Content -->
        <section id="content" class="table-layout animated fadeIn">

            <!-- begin: .tray-center -->
            <div class="tray tray-center">
                <p>Welcome, <b>Admin</b></p>
<form method="POST" action="" id="contact">
              <div class="panel-body bg-light p30">
                <div class="row">
                  <div class="col-sm-7 pr30">

                    <p><b>Add Bus details</b></p>                    

                    <div class="section">
                      <label for="username" class="field-label text-muted fs18 mb10">Bus Number</label>
                     <br>
                        <input type="text" name="bid" id="username" class="gui-input" placeholder="Enter Bus Number">
                        
                        
                    </div>
                    <div class="section">
                      <label for="username" class="field-label text-muted fs18 mb10">Num of Seat</label>
                     <br> 
                        <input type="text" name="bseat" id="username" class="gui-input" placeholder="Enter Num of Seat">
                    </div>


                    <div class="section">
                      <label for="username" class="field-label text-muted fs18 mb10">Bus Registeration Number</label>
                      <br>
                        <input type="text" name="brnum" id="username" class="gui-input" placeholder="Enter Bus Registeration number">
                    </div>

                  </div>
                  
                </div> 
              </div>
        <div class="panel-footer clearfix p10 ph15">
                <button type="" class="button btn-primary mr10 pull-left">Add Bus</button>
              </div>           
</form>

<form method="GET" action="" id="deleteDriver">
              <div class="panel-body bg-light p30">
                <div class="row">
                  <div class="col-sm-7 pr30">

                    <p><b>Delete Bus</b></p>                    

                    <div class="section">
                      <label for="username" class="field-label text-muted fs18 mb10">Bus id</label>
                     <br>
                        <input type="text" name="bid" id="username" class="gui-input" placeholder="Enter Bus unique id">
                        
                        
                    </div>
                   

                  </div>
                  
                </div> 
              </div>
        <div class="panel-footer clearfix p10 ph15">
                <button type="" class="button btn-primary mr10 pull-left">Delete Bus</button>
              </div>           
            </form>
<div class="panel-body bg-light p30">
                <div class="row">
                  <div class="col-sm-7 pr30">
 <div class="panel-heading">
              <span class="panel-title">
                <span class="fa fa-table"></span>Bus Details</span>
              
            </div>
              <div class="panel-body pn">
              <div class="">
                <table class="table table-striped">
                 <?php 
                  
                    $sql="select * from bustb ";
                    $result = $conn->query($sql);
                    if($result->num_rows >0) 
                    {$i=0;
                       echo' <tr><th>sl.no</th><th>Bus id</th><th>Bus Number</th><th>Num of Seats</th><th>Registeration No</th></tr>';
                    // output data of each row
                    while($row = $result->fetch_assoc()) 
                    {
                    $i++; 
                    echo ('<tr><td>'.$i.'</td><td>'.$row["bid"].'</td><td>'.$row["bNum"].'</td><td>'.$row["bSeat"].'</td><td>'.$row["brNum"].'</td></tr>');
                    
                    }
                    }
    else
    {
    echo"0 results";
        }
$conn->close();
                  ?>
       </table>
              </div>
            </div>

</div>
</div>
</div>


              <!-- end .form-body section -->
              <!-- end .form-footer section -->
 
            </div>

        </section>                    
        <!-- End: Content -->
<?php
   include("adminfooter.php");

   ?>