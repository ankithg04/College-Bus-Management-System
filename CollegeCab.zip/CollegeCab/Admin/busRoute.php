<?php
   include("adminheader.php"); 
if($_SERVER["REQUEST_METHOD"] == "GET") {
      // username and password sent from form
$val1 = mysqli_real_escape_string($conn,$_GET['busDDL']);
$val2 = mysqli_real_escape_string($conn,$_GET['routeDDL']);
$sql2="INSERT INTO busroutetb (bid,rid) values($val1,$val2)";
//echo'<script>alert('')</scriptt>'
if ($conn->query($sql2) === TRUE){
            $message="INSERTED SUCESSFULLY";
            echo"<script>alert('');</scriptt>";
        }else{
            $message ="NOT INSERTED";
        }

header("location: busDriver.php");
   }

   ?>
<script type="text/javascript">
  $var value2='hi';
                    </script>
    <!-- Start: Content-Wrapper -->
    <section id="content_wrapper">

        <header id="topbar" class="alt">
            <div class="topbar-left">
                <ol class="breadcrumb">
                    <li class="crumb-active">
                        <a href="dashboard.html">Dashboard</a>
                    </li>
                    <li class="crumb-icon">
                        <a href="dashboard.html">
                            <span class="glyphicon glyphicon-home"></span>
                        </a>
                    </li>
                    <li class="crumb-link">
                        <a href="index.html">Home</a>
                    </li>
                    <li class="crumb-trail">Bus-Driver Details</li>
                </ol>
            </div>
               </header>
        <!-- End: Topbar -->

        <!-- Begin: Content -->
        <section id="content" class="table-layout animated fadeIn">

            <!-- begin: .tray-center -->
            <div class="tray tray-center">
                <p>Welcome, <b>Admin</b></p>
    <form method="GET" action="" id="contact">
              <div class="panel-body bg-light p30">
                <div class="row">
                  <div class="col-sm-7 pr30">

                    <p><b>Bus-Driver details</b></p>                    

                    <div class="section">
                      <label for="username" class="field-label text-muted fs18 mb10">Select Bus Registeration Number</label> 
                     <br>
                     <form metod="post" action ="" ">
                        <select name="busDDL"><option value="0">-----SELECT-----</option>
                        <?php
                        $sql1="SELECT B.bid,B.brNum from bustb B where B.bid NOT IN (SELECT BR.bid from busroutetb BR)";
#<select name="busDDL" onchange="window.location='busdriver.php?bid='+(this.value);"><option value="0">-----SELECT-----</option>

                          echo'';

                           $result = $conn->query($sql1);
                            if($result->num_rows >0) 
                            {
                                while($row = $result->fetch_assoc()) 
                                  {
                                echo '<option value="'.$row["bid"].'">'.$row["brNum"].'</option>';
                                  
                                  }
                            }
                            else{


                            }

                          echo"</select>";
                        ?>   
                    </div>

                    
                    <div class="section">
                      <label for="username" class="field-label text-muted fs18 mb10">Select Route</label>
                     <br> 
                      <select name="routeDDL"><option value="0">-----SELECT-----</option>
                        <?php
                        $sql3="select rid,rfrom,rto from routetb where rid NOT IN(SELECT rid from busroutetb)" ;

                          echo'';

                           $result3 = $conn->query($sql3);
                            if($result3->num_rows >0) 
                            {
                                while($row3 = $result3->fetch_assoc()) 
                                  {
                                echo '<option value="'.$row3["rid"].'">'.$row3["rfrom"].' to '.$row3["rto"].'</option>';
                                  
                                  }
                            }
                            else{


                            }

                          echo"</select>";
                        ?>


                    </div>


                  </div>
                  
                </div> 
              </div>
        <div class="panel-footer clearfix p10 ph15">
                <button type="" class="button btn-primary mr10 pull-left">Add Bus to Route</button>
              </div>           
</form>

<div class="panel-body bg-light p30">
                <div class="row">
                  <div class="col-sm-7 pr30">
 <div class="panel-heading">
              <span class="panel-title">
                <span class="fa fa-table"></span>Bus-Route Details</span>
              
            </div>
              <div class="panel-body pn">
              <div class="">
                <table class="table table-striped">
                 <?php 
                  
                    $sql="select D.rfrom,D.rto,B.brNum,B.bNum,B.bid from busroutetb BD INNER JOIN bustb B on B.bid=BD.bid INNER JOIN routetb D on D.rid=BD.rid";
                    $result = $conn->query($sql);
                    if($result->num_rows >0) 
                    {$i=0;
                       echo' <tr><th>sl.no</th><th>Source to destination</th><th>Bus-Registeration Number</th><th>Bus-Number</th><th>delete</th></tr>';
                    // output data of each row
                    while($row = $result->fetch_assoc()) 
                    {
                    $i++; 
                    echo ('<tr><td>'.$i.'</td><td>'.$row["rfrom"].' to '.$row["rto"].'</td><td>'.$row["brNum"].'</td><td>'.$row["bNum"].'</td><td><a href="#">delete</a></td></tr>');
                    
                    }
                    }
    else
    {
    echo"0 results";
        }
$conn->close();
                  ?>
       </table>
              </div>
            </div>

</div>
</div>
</div>


              <!-- end .form-body section -->
              <!-- end .form-footer section -->
 
            </div>

        </section>                    
        <!-- End: Content -->
<?php
   include("adminfooter.php");

   ?>