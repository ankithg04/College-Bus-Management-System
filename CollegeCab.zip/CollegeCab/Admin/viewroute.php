<?php
   include("adminheader.php");
?>
    <!-- End: Sidebar Left -->

    <!-- Start: Content-Wrapper -->
    <section id="content_wrapper">

        <!-- Start: Topbar-Dropdown -->

        <!-- Start: Topbar -->
        <header id="topbar" class="alt">
            <div class="topbar-left">
                <ol class="breadcrumb">
                    <li class="crumb-active">
                        <a href="dashboard.html">Dashboard</a>
                    </li>
                    <li class="crumb-icon">
                        <a href="dashboard.html">
                            <span class="glyphicon glyphicon-home"></span>
                        </a>
                    </li>
                    <li class="crumb-link">
                        <a href="index.html">Home</a>
                    </li>
                    <li class="crumb-trail">Route Details</li>
                </ol>
            </div>
               </header>
        <!-- End: Topbar -->

        <!-- Begin: Content -->
        <section id="content" class="table-layout animated fadeIn">

            <!-- begin: .tray-center -->
            <div class="tray tray-center">
                <p>Welcome, <b>Admin</b></p>

              <div class="panel-body bg-light p30">
                <div class="row">
                  <div class="col-sm-7 pr30">

                           <?php 

        if($_SERVER["REQUEST_METHOD"] == "GET") {
      // username and password sent from form 
    
            $Rid = mysqli_real_escape_string($conn,$_GET['Rid']);
     
            $sql="Select *from Routetb where Rid=$Rid";
                    $result = $conn->query($sql);
                    if($result->num_rows>0) 
                    {
                      $i=0;
                       
                    // output data of each row
                    while($row = $result->fetch_assoc()) 
                    {
                    echo' <p>Stops <b>From</b> '.$row["Rfrom"].' <b>to</b> '.$row["Rto"].' are:<br>';
                    
$states1 = explode(' ',nl2br($row["Rstops"])); 
print('/>');
foreach ( $states1 as $i => $value )
print("$value <br>");


                     //echo nl2br('<p style ="margin-left:50px; color:black;">'.$row["Rstops"].'</p>');
                    
                    }
                    }

                    }
        else
             {
               echo"0 results";
              }

                           ?>   

                    
                  </div>
                  
                </div> 
              </div>
       




              <!-- end .form-body section -->
              <!-- end .form-footer section -->
 
            </div>

        </section>                    
        <!-- End: Content -->
<?php
   include("adminfooter.php");

   ?>