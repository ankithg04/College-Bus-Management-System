<?php


 include("db.php");
 //if($_SERVER["REQUEST_METHOD"] == "GET") {
      // username and password sent from form 
    
            $Sid = mysqli_real_escape_string($conn,$_GET['sid']);
     
            $sql="Delete from studbustb where sid=$Sid";
                    if ($conn->query($sql) === TRUE){
            $message="Approved successfully";
            print('hiii');
            header("location: studbus.php");
        }else{
            $message ="Not Approved";
              header("location: studbus.php");
        }
     // }

?>