<?php
   include("adminheader.php");
   include("db.php");
if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
  
      $val1 = mysqli_real_escape_string($conn,$_POST['Rstart']);
      $val2 = mysqli_real_escape_string($conn,$_POST['Rdest']); 
      $val3 = mysqli_real_escape_string($conn,$_POST['stops']);
      $sql="INSERT INTO Routetb (Rfrom,Rto,Rstops)
    VALUES('$val1','$val2','$val3')";
        if ($conn->query($sql) === TRUE){
            $message="INSERTED SUCESSFULLY";
        }else{
            $message ="NOT INSERTED";
        }

header("location: RouteDet.php");
   }
if($_SERVER["REQUEST_METHOD"] == "GET") {
      // username and password sent from form 
  
      $Rid = mysqli_real_escape_string($conn,$_GET['Rid']);
     
      $sql="Delete from Routetb where Rid=$Rid";
        if ($conn->query($sql) === TRUE){
            $message="DELETED SUCESSFULLY";
        }else{
            $message ="NOT DELETED";
        }

 header("location: RouteDet.php");
   }

   ?>
    <!-- End: Sidebar Left -->

    <!-- Start: Content-Wrapper -->
    <section id="content_wrapper">

        <!-- Start: Topbar-Dropdown -->

        <!-- Start: Topbar -->
        <header id="topbar" class="alt">
            <div class="topbar-left">
                <ol class="breadcrumb">
                    <li class="crumb-active">
                        <a href="dashboard.html">Dashboard</a>
                    </li>
                    <li class="crumb-icon">
                        <a href="dashboard.html">
                            <span class="glyphicon glyphicon-home"></span>
                        </a>
                    </li>
                    <li class="crumb-link">
                        <a href="index.html">Home</a>
                    </li>
                    <li class="crumb-trail">Route Details</li>
                </ol>
            </div>
               </header>
        <!-- End: Topbar -->

        <!-- Begin: Content -->
        <section id="content" class="table-layout animated fadeIn">

            <!-- begin: .tray-center -->
            <div class="tray tray-center">
                <p>Welcome, <b>Admin</b></p>
<form method="POST" action="" id="contact">
              <div class="panel-body bg-light p30">
                <div class="row">
                  <div class="col-sm-7 pr30">

                    <p><b>Add Route details</b></p>                    

                    <div class="section">
                      <label for="username" class="field-label text-muted fs18 mb10">Route Starts from </label>
                     <br>
                        <input type="text" name="Rstart" id="username" class="gui-input" placeholder="Enter place where route starts">
                        
                        
                    </div>
                    <div class="section">
                      <label for="username" class="field-label text-muted fs18 mb10">Route Ends at</label>
                     <br> 
                        <input type="text" name="Rdest" id="username" class="gui-input" placeholder="Enter Place of the route Destination">
                    </div>


                    <div class="section">
                      <label for="username" class="field-label text-muted fs18 mb10">Stops</label>
                      <br>
                        <textarea type="text" name="stops" rows="40" id="username" class="gui-input" placeholder="Enter Stops"></textarea>
                    </div>

                  </div>
                  
                </div> 
              </div>
        <div class="panel-footer clearfix p10 ph15">
                <button type="" class="button btn-primary mr10 pull-left">Add Route</button>
              </div>           
</form>

<form method="GET" action="" id="deleteDriver">
              <div class="panel-body bg-light p30">
                <div class="row">
                  <div class="col-sm-7 pr30">

                    <p><b>Delete driver</b></p>                    

                    <div class="section">
                      <label for="username" class="field-label text-muted fs18 mb10">Route id</label>
                     <br>
                        <input type="text" name="Rid" id="username" class="gui-input" placeholder="Enter Route id">
                        
                        
                    </div>
                   

                  </div>
                  
                </div> 
              </div>
        <div class="panel-footer clearfix p10 ph15">
                <button type="" class="button btn-primary mr10 pull-left">Delete Route</button>
              </div>           
            </form>
<div class="panel-body bg-light p30">
                <div class="row">
                  <div class="col-sm-7 pr30">
 <div class="panel-heading">
              <span class="panel-title">
                <span class="fa fa-table"></span>Driver Details</span>
              
            </div>
              <div class="panel-body pn">
              <div class="">
                <table class="table table-striped">
                 <?php 
                  
                    $sql="select* from Routetb ";
                    $result = $conn->query($sql);
                    if($result->num_rows >0) 
                    {$i=0;
                       echo' <tr><th>sl.no</th><th>Route id</th><th>Route Source </th><th>Route Destination</th><th>View Route Details</th></tr>';
                    // output data of each row
                    while($row = $result->fetch_assoc()) 
                    {
                    $i++; 
                    echo ('<tr><td>'.$i.'</td><td>'.$row["Rid"].'</td><td>'.$row["Rfrom"].'</td><td>'.$row["Rto"].'</td><td><a href="viewroute.php?Rid='.$row["Rid"].'">View</a></td></tr>');
                    
                    }
                    }
    else
    {
    echo"0 results";
        }
$conn->close();
                  ?>
       </table>
              </div>
            </div>

</div>
</div>
</div>


              <!-- end .form-body section -->
              <!-- end .form-footer section -->
 
            </div>

        </section>                    
        <!-- End: Content -->
<?php
   include("adminfooter.php");

   ?>