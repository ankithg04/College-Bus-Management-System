<?php
   include("adminheader.php");
if($_SERVER["REQUEST_METHOD"] == "GET") {
      // username and password sent from form 
  
      $Sid = mysqli_real_escape_string($conn,$_GET['Sid']);
     
      $sql="Delete from Studenttb where sid=$Sid";
        if ($conn->query($sql) === TRUE){
            $message="DELETED SUCESSFULLY";
        }else{
            $message ="NOT DELETED";
        }

header("location: RouteDet.php");
   }

   ?>
    <!-- End: Sidebar Left -->

    <!-- Start: Content-Wrapper -->
    <section id="content_wrapper">

        <!-- Start: Topbar-Dropdown -->

        <!-- Start: Topbar -->
        <header id="topbar" class="alt">
            <div class="topbar-left">
                <ol class="breadcrumb">
                    <li class="crumb-active">
                        <a href="dashboard.html">Dashboard</a>
                    </li>
                    <li class="crumb-icon">
                        <a href="dashboard.html">
                            <span class="glyphicon glyphicon-home"></span>
                        </a>
                    </li>
                    <li class="crumb-link">
                        <a href="index.html">Home</a>
                    </li>
                    <li class="crumb-trail">Student Details</li>
                </ol>
            </div>
               </header>
        <!-- End: Topbar -->

        <!-- Begin: Content -->
        <section id="content" class="table-layout animated fadeIn">

            <!-- begin: .tray-center -->
            <div class="tray tray-center">
                <p>Welcome, <b>Admin</b></p>



<div class="panel-body bg-light p30">
                <div class="row">
                  <div class="col-sm-7 pr30">
 <div class="panel-heading">
              <span class="panel-title">
                <span class="fa fa-table"></span>Not Approved Student Details</span>
              
            </div>
              <div class="panel-body pn">
              <div class="">
                <table class="table table-striped">
                 <?php 
                  
                    $sql="select* from Studenttb where approve='no' ";
                    $result = $conn->query($sql);
                    if($result->num_rows >0) 
                    {$i=0;
                       echo' <tr><th>sl.no</th><th>Student id</th><th>USN</th><th>Name</th><th>Phone Num</th><th>Stop</th></tr>';
                    // output data of each row
                    while($row = $result->fetch_assoc()) 
                    {
                    $i++; 
                    echo ('<tr><td>'.$i.'</td><td>'.$row["sid"].'</td><td>'.$row["usn"].'</td><td>'.$row["name"].'</td><td>'.$row["phonenum"].'</td><td><a href="approvestud.php?sid='.$row["sid"].'">Approve</a></td></tr>');
                    
                    }
                    }
                      else
                   {
                    echo"0 results";
                   }
                // $conn->close();
                  ?>
              </table>
              </div>
            </div>

        </div>
        </div>
        </div>
<div class="panel-body bg-light p30">
                <div class="row">
                  <div class="col-sm-7 pr30">
 <div class="panel-heading">
              <span class="panel-title">
                <span class="fa fa-table"></span>Approved Student Details</span>
                
              
            </div>
              <div class="panel-body pn">
              <div class="">
                <table class="table table-striped">
                 <?php 
                  
                    $sql="select* from Studenttb where approve='yes' ";
                    $result = $conn->query($sql);
                    if($result->num_rows >0) 
                    {$i=0;
                       echo' <tr><th>sl.no</th><th>Student id</th><th>USN</th><th>Name</th><th>Phone Num</th><th>Stop</th></tr>';
                    // output data of each row
                    while($row = $result->fetch_assoc()) 
                    {
                    $i++; 
                    echo ('<tr><td>'.$i.'</td><td>'.$row["sid"].'</td><td>'.$row["usn"].'</td><td>'.$row["name"].'</td><td>'.$row["phonenum"].'</td><td><a href="notapprovestud.php?sid='.$row["sid"].'">disapprove</a></td></tr>');
                    
                    }
                    }
                      else
                   {
                    echo"0 results";
                   }
                // $conn->close();
                  ?>
              </table>
              </div>
            </div>

        </div>
        </div>
        </div>

<form method="GET" action="" id="deleteDriver">
              <div class="panel-body bg-light p30">
                <div class="row">
                  <div class="col-sm-7 pr30">

                    <p><b>Delete </b>Student</p>                    

                    <div class="section">
                      <label for="username" class="field-label text-muted fs18 mb10">student id</label>
                     <br>
                        <input type="text" name="Sid" id="username" class="gui-input" placeholder="Enter Student id">
                        
                        
                    </div>
                   

                  </div>
                  
                </div> 
              </div>
        <div class="panel-footer clearfix p10 ph15">
                <button type="" class="button btn-primary mr10 pull-left">Delete Student</button>
              </div>           
            </form>

              <!-- end .form-body section -->
              <!-- end .form-footer section -->
 
            </div>

        </section>                    
        <!-- End: Content -->
<?php
   include("adminfooter.php");

   ?>